﻿using System;
using System.Collections.Generic;

namespace SAExpiations.Models
{
    public partial class LocalServiceArea
    {
        public string LocalServiceAreaCode { get; set; } = null!;
        public string? LocalServiceArea1 { get; set; }
    }
}
