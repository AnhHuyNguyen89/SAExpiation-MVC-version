﻿using System;
using System.Collections.Generic;

namespace SAExpiations.Models
{
    public partial class PhotoRejectionReason
    {
        public int PhotoRejectionCode { get; set; }
        public string? PhotoRejecetionReason { get; set; }
    }
}
