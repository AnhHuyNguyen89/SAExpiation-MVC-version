﻿namespace SAExpiations.ViewModels
{
    public class LocalAreaVM
    {
        public string localServiceAreaCode { get; set; }
        public string localServiceArea { get; set; }
        public string? localServiceArea1 { get; set; }
        public int? RegionCount { get; set; }
    }
}
